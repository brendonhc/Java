Arquivo zip gerado em: 26/04/2018 17:04:26 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Lista 2 - Exercício 2