public class FullStackException extends StackException {
    FullStackException() {};

    FullStackException(String msg) {
        super(msg);
    }
}
